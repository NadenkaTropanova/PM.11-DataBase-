package com.salesregister.service.exception;

public class AuthenticationException extends Exception {

}
