package com.salesregister.service.exception;

public class UserAlreadyExistsException extends Exception {
}

