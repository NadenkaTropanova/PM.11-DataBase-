package com.salesregister.controller;

import com.salesregister.Main;
import com.salesregister.controller.popup.PopupWindow;
import com.salesregister.request.OperationRequest;
import com.salesregister.service.OperationService;
import com.salesregister.service.UserService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.math.BigDecimal;

@Controller
public class AddOperationController {

    @Autowired
    private OperationService service;

    @FXML
    private TextField name;

    @FXML
    private TextField price;

    @FXML
    private TextField vid;

    @FXML
    private TextField ves;

    @FXML
    private TextField proba;

    @FXML
    private TextField master;

    @FXML
    void add() {
        if (name.getText().length() == 0) {
            PopupWindow.openWindow("Ошибка", "Заполните название изделия");
            return;
        }

        if (!price.getText().matches("[0-9]+[.,]?[0-9]*")) {
            PopupWindow.openWindow("Ошибка", "Цена может содержать только цифры и точку(если требуется)");
            return;
        }

        if (vid.getText().length() == 0) {
            PopupWindow.openWindow("Ошибка", "Заполните вид изделия");
            return;
        }

        if (ves.getText().length() == 0) {
            PopupWindow.openWindow("Ошибка", "Заполните вес изделия");
            return;
        }

        if (proba.getText().length() == 0) {
            PopupWindow.openWindow("Ошибка", "Заполните пробу изделия (585, 925");
            return;
        }

        if (master.getText().length() == 0) {
            PopupWindow.openWindow("Ошибка", "Заполните ФИО мастера");
            return;
        }

        OperationRequest request = new OperationRequest();
        request.setName(name.getText());
        request.setPrice(new BigDecimal(price.getText().replace(',', '.')));
        request.setVes(Double.valueOf(ves.getText().replace(',', '.')));
        request.setVid(vid.getText());
        request.setProba(Integer.valueOf(proba.getText()));
        request.setMaster(master.getText());

        service.addOperation(request);

        name.setText("");
        price.setText("");
        ves.setText("");
        vid.setText("");
        proba.setText("");
        master.setText("");

    }

    @FXML
    void back(ActionEvent event) throws IOException {
        OperationController.load();
    }

    public static void load() throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("/add_operation.fxml"));
        loader.setControllerFactory(Main.getApplicationContext().getBeanFactory()::getBean);
        Parent view = loader.load();
        Main.getStage().setScene(new Scene(view));
        Main.getStage().show();
    }
}
