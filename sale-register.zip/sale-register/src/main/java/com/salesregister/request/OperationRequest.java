package com.salesregister.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OperationRequest {
    private String name;
    private BigDecimal price;
    private String vid;
    private Double ves;
    private Integer proba;
    private String master;

}
