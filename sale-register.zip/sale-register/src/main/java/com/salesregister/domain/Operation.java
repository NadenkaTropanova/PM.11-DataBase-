package com.salesregister.domain;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@Table(name = "operations")
public class Operation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private BigDecimal price;
    private String vid;
    private Double ves;
    private Integer proba;
    @Temporal(value = TemporalType.DATE)
    private Date date;
    private String master;

    @OneToOne
    private User user;
}
